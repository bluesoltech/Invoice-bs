import React from "react";

function Footer() {
  return <div className="w-full bg-blue-900 h-[25px] absolute bottom-0"></div>;
}

export default Footer;
