// export const BASE_URL = "http://localhost:8080/api";
export const BASE_URL = "http://3.110.5.70:8080/api";
